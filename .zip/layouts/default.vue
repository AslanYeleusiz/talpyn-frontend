<template>
    <div>
        <cstHeader />
        <Nuxt />
        <Footer />
    </div>
</template>


<script>
    //import Header from '@/components/Header.vue'
    export default {
        components: {
            //Header,
        },
        
    }
</script>