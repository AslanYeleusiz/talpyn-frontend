export const CstHeader = () => import('../..\\components\\cstHeader.vue' /* webpackChunkName: "components/cst-header" */).then(c => wrapFunctional(c.default || c))
export const Footer = () => import('../..\\components\\Footer.vue' /* webpackChunkName: "components/footer" */).then(c => wrapFunctional(c.default || c))
export const HeaderKroshki = () => import('../..\\components\\header_kroshki.vue' /* webpackChunkName: "components/header-kroshki" */).then(c => wrapFunctional(c.default || c))
export const HeaderOlimp = () => import('../..\\components\\header_olimp.vue' /* webpackChunkName: "components/header-olimp" */).then(c => wrapFunctional(c.default || c))
export const FormsBigBtn = () => import('../..\\components\\forms\\bigBtn.vue' /* webpackChunkName: "components/forms-big-btn" */).then(c => wrapFunctional(c.default || c))
export const FormsBtn = () => import('../..\\components\\forms\\btn.vue' /* webpackChunkName: "components/forms-btn" */).then(c => wrapFunctional(c.default || c))
export const FormsBtnGroup = () => import('../..\\components\\forms\\btnGroup.vue' /* webpackChunkName: "components/forms-btn-group" */).then(c => wrapFunctional(c.default || c))
export const FormsCertBtn = () => import('../..\\components\\forms\\certBtn.vue' /* webpackChunkName: "components/forms-cert-btn" */).then(c => wrapFunctional(c.default || c))
export const FormsCertdownload = () => import('../..\\components\\forms\\certdownload.vue' /* webpackChunkName: "components/forms-certdownload" */).then(c => wrapFunctional(c.default || c))
export const FormsCheckbox = () => import('../..\\components\\forms\\checkbox.vue' /* webpackChunkName: "components/forms-checkbox" */).then(c => wrapFunctional(c.default || c))
export const FormsCstBtn = () => import('../..\\components\\forms\\cstBtn.vue' /* webpackChunkName: "components/forms-cst-btn" */).then(c => wrapFunctional(c.default || c))
export const FormsCstInput = () => import('../..\\components\\forms\\cstInput.vue' /* webpackChunkName: "components/forms-cst-input" */).then(c => wrapFunctional(c.default || c))
export const FormsCstInputDisabled = () => import('../..\\components\\forms\\cstInputDisabled.vue' /* webpackChunkName: "components/forms-cst-input-disabled" */).then(c => wrapFunctional(c.default || c))
export const FormsCstPasswordInput = () => import('../..\\components\\forms\\cstPasswordInput.vue' /* webpackChunkName: "components/forms-cst-password-input" */).then(c => wrapFunctional(c.default || c))
export const FormsCstTextarea = () => import('../..\\components\\forms\\cstTextarea.vue' /* webpackChunkName: "components/forms-cst-textarea" */).then(c => wrapFunctional(c.default || c))
export const FormsEditBtn = () => import('../..\\components\\forms\\editBtn.vue' /* webpackChunkName: "components/forms-edit-btn" */).then(c => wrapFunctional(c.default || c))
export const FormsEmptyBtn = () => import('../..\\components\\forms\\emptyBtn.vue' /* webpackChunkName: "components/forms-empty-btn" */).then(c => wrapFunctional(c.default || c))
export const FormsExitBtn = () => import('../..\\components\\forms\\exitBtn.vue' /* webpackChunkName: "components/forms-exit-btn" */).then(c => wrapFunctional(c.default || c))
export const FormsExitDefaultBtn = () => import('../..\\components\\forms\\exitDefaultBtn.vue' /* webpackChunkName: "components/forms-exit-default-btn" */).then(c => wrapFunctional(c.default || c))
export const FormsGlassBtn = () => import('../..\\components\\forms\\glassBtn.vue' /* webpackChunkName: "components/forms-glass-btn" */).then(c => wrapFunctional(c.default || c))
export const FormsGotoBackBtn = () => import('../..\\components\\forms\\gotoBackBtn.vue' /* webpackChunkName: "components/forms-goto-back-btn" */).then(c => wrapFunctional(c.default || c))
export const FormsGreenBtn = () => import('../..\\components\\forms\\greenBtn.vue' /* webpackChunkName: "components/forms-green-btn" */).then(c => wrapFunctional(c.default || c))
export const FormsQBtn = () => import('../..\\components\\forms\\qBtn.vue' /* webpackChunkName: "components/forms-q-btn" */).then(c => wrapFunctional(c.default || c))
export const FormsReportBtn = () => import('../..\\components\\forms\\reportBtn.vue' /* webpackChunkName: "components/forms-report-btn" */).then(c => wrapFunctional(c.default || c))
export const FormsSaveBtn = () => import('../..\\components\\forms\\saveBtn.vue' /* webpackChunkName: "components/forms-save-btn" */).then(c => wrapFunctional(c.default || c))
export const FormsWarninger = () => import('../..\\components\\forms\\warninger.vue' /* webpackChunkName: "components/forms-warninger" */).then(c => wrapFunctional(c.default || c))
export const SvgArchiveBook = () => import('../..\\components\\svg\\archive-book.vue' /* webpackChunkName: "components/svg-archive-book" */).then(c => wrapFunctional(c.default || c))
export const SvgArrowLeft = () => import('../..\\components\\svg\\arrow-left.vue' /* webpackChunkName: "components/svg-arrow-left" */).then(c => wrapFunctional(c.default || c))
export const SvgArrowLeftCopy = () => import('../..\\components\\svg\\arrowLeftCopy.vue' /* webpackChunkName: "components/svg-arrow-left-copy" */).then(c => wrapFunctional(c.default || c))
export const SvgArrowBottom = () => import('../..\\components\\svg\\arrow_bottom.vue' /* webpackChunkName: "components/svg-arrow-bottom" */).then(c => wrapFunctional(c.default || c))
export const SvgBook = () => import('../..\\components\\svg\\book.vue' /* webpackChunkName: "components/svg-book" */).then(c => wrapFunctional(c.default || c))
export const SvgCup = () => import('../..\\components\\svg\\cup.vue' /* webpackChunkName: "components/svg-cup" */).then(c => wrapFunctional(c.default || c))
export const SvgDaryn = () => import('../..\\components\\svg\\daryn.vue' /* webpackChunkName: "components/svg-daryn" */).then(c => wrapFunctional(c.default || c))
export const SvgDestroy = () => import('../..\\components\\svg\\destroy.vue' /* webpackChunkName: "components/svg-destroy" */).then(c => wrapFunctional(c.default || c))
export const SvgDoc = () => import('../..\\components\\svg\\doc.vue' /* webpackChunkName: "components/svg-doc" */).then(c => wrapFunctional(c.default || c))
export const SvgDocumentText = () => import('../..\\components\\svg\\documentText.vue' /* webpackChunkName: "components/svg-document-text" */).then(c => wrapFunctional(c.default || c))
export const SvgDownload = () => import('../..\\components\\svg\\download.vue' /* webpackChunkName: "components/svg-download" */).then(c => wrapFunctional(c.default || c))
export const SvgDownloadFile = () => import('../..\\components\\svg\\download_file.vue' /* webpackChunkName: "components/svg-download-file" */).then(c => wrapFunctional(c.default || c))
export const SvgDwb = () => import('../..\\components\\svg\\dwb.vue' /* webpackChunkName: "components/svg-dwb" */).then(c => wrapFunctional(c.default || c))
export const SvgEdit = () => import('../..\\components\\svg\\edit.vue' /* webpackChunkName: "components/svg-edit" */).then(c => wrapFunctional(c.default || c))
export const SvgEx = () => import('../..\\components\\svg\\ex.vue' /* webpackChunkName: "components/svg-ex" */).then(c => wrapFunctional(c.default || c))
export const SvgFolder = () => import('../..\\components\\svg\\folder.vue' /* webpackChunkName: "components/svg-folder" */).then(c => wrapFunctional(c.default || c))
export const SvgHome = () => import('../..\\components\\svg\\home.vue' /* webpackChunkName: "components/svg-home" */).then(c => wrapFunctional(c.default || c))
export const SvgImporter = () => import('../..\\components\\svg\\importer.vue' /* webpackChunkName: "components/svg-importer" */).then(c => wrapFunctional(c.default || c))
export const SvgInfo = () => import('../..\\components\\svg\\info.vue' /* webpackChunkName: "components/svg-info" */).then(c => wrapFunctional(c.default || c))
export const SvgLogout = () => import('../..\\components\\svg\\logout.vue' /* webpackChunkName: "components/svg-logout" */).then(c => wrapFunctional(c.default || c))
export const SvgMedal = () => import('../..\\components\\svg\\medal.vue' /* webpackChunkName: "components/svg-medal" */).then(c => wrapFunctional(c.default || c))
export const SvgMedalStar = () => import('../..\\components\\svg\\medalStar.vue' /* webpackChunkName: "components/svg-medal-star" */).then(c => wrapFunctional(c.default || c))
export const SvgMonitorRecorder = () => import('../..\\components\\svg\\monitorRecorder.vue' /* webpackChunkName: "components/svg-monitor-recorder" */).then(c => wrapFunctional(c.default || c))
export const SvgNewbe = () => import('../..\\components\\svg\\newbe.vue' /* webpackChunkName: "components/svg-newbe" */).then(c => wrapFunctional(c.default || c))
export const SvgNews24 = () => import('../..\\components\\svg\\news24.vue' /* webpackChunkName: "components/svg-news24" */).then(c => wrapFunctional(c.default || c))
export const SvgNotification = () => import('../..\\components\\svg\\notification.vue' /* webpackChunkName: "components/svg-notification" */).then(c => wrapFunctional(c.default || c))
export const SvgProfileCircle = () => import('../..\\components\\svg\\profile-circle.vue' /* webpackChunkName: "components/svg-profile-circle" */).then(c => wrapFunctional(c.default || c))
export const SvgRefresh = () => import('../..\\components\\svg\\refresh.vue' /* webpackChunkName: "components/svg-refresh" */).then(c => wrapFunctional(c.default || c))
export const SvgTeacher = () => import('../..\\components\\svg\\teacher.vue' /* webpackChunkName: "components/svg-teacher" */).then(c => wrapFunctional(c.default || c))
export const SvgVideoSquare = () => import('../..\\components\\svg\\videoSquare.vue' /* webpackChunkName: "components/svg-video-square" */).then(c => wrapFunctional(c.default || c))
export const PopupsConfirmedPopup = () => import('../..\\components\\popups\\confirmedPopup.vue' /* webpackChunkName: "components/popups-confirmed-popup" */).then(c => wrapFunctional(c.default || c))
export const PopupsKateSurakPopup = () => import('../..\\components\\popups\\kateSurakPopup.vue' /* webpackChunkName: "components/popups-kate-surak-popup" */).then(c => wrapFunctional(c.default || c))
export const PopupsOlimpiadaPopup = () => import('../..\\components\\popups\\olimpiadaPopup.vue' /* webpackChunkName: "components/popups-olimpiada-popup" */).then(c => wrapFunctional(c.default || c))
export const PopupsOplataPopup = () => import('../..\\components\\popups\\oplataPopup.vue' /* webpackChunkName: "components/popups-oplata-popup" */).then(c => wrapFunctional(c.default || c))
export const PopupsVideoPopup = () => import('../..\\components\\popups\\videoPopup.vue' /* webpackChunkName: "components/popups-video-popup" */).then(c => wrapFunctional(c.default || c))
export const MaterialsFormsDengeiBlock = () => import('../..\\components\\materials\\forms\\dengeiBlock.vue' /* webpackChunkName: "components/materials-forms-dengei-block" */).then(c => wrapFunctional(c.default || c))
export const MaterialsMyOlimpiadaBelsendiOlimpiada = () => import('../..\\components\\materials\\my_olimpiada\\belsendi_olimpiada.vue' /* webpackChunkName: "components/materials-my-olimpiada-belsendi-olimpiada" */).then(c => wrapFunctional(c.default || c))
export const MaterialsMyOlimpiadaFaqs = () => import('../..\\components\\materials\\my_olimpiada\\faqs.vue' /* webpackChunkName: "components/materials-my-olimpiada-faqs" */).then(c => wrapFunctional(c.default || c))
export const MaterialsMyOlimpiadaMuragat = () => import('../..\\components\\materials\\my_olimpiada\\muragat.vue' /* webpackChunkName: "components/materials-my-olimpiada-muragat" */).then(c => wrapFunctional(c.default || c))
export const MaterialsMyOlimpiadaOtkenOlimps = () => import('../..\\components\\materials\\my_olimpiada\\otken_olimps.vue' /* webpackChunkName: "components/materials-my-olimpiada-otken-olimps" */).then(c => wrapFunctional(c.default || c))

// nuxt/nuxt.js#8607
function wrapFunctional(options) {
  if (!options || !options.functional) {
    return options
  }

  const propKeys = Array.isArray(options.props) ? options.props : Object.keys(options.props || {})

  return {
    render(h) {
      const attrs = {}
      const props = {}

      for (const key in this.$attrs) {
        if (propKeys.includes(key)) {
          props[key] = this.$attrs[key]
        } else {
          attrs[key] = this.$attrs[key]
        }
      }

      return h(options, {
        on: this.$listeners,
        attrs,
        props,
        scopedSlots: this.$scopedSlots,
      }, this.$slots.default)
    }
  }
}
