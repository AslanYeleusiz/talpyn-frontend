import Vue from 'vue'
import Router from 'vue-router'
import { normalizeURL, decode } from 'ufo'
import { interopDefault } from './utils'
import scrollBehavior from './router.scrollBehavior.js'

const _5a786f1e = () => interopDefault(import('..\\pages\\about.vue' /* webpackChunkName: "pages/about" */))
const _87b97366 = () => interopDefault(import('..\\pages\\login.vue' /* webpackChunkName: "pages/login" */))
const _75c1033a = () => interopDefault(import('..\\pages\\olimpiada\\index.vue' /* webpackChunkName: "pages/olimpiada/index" */))
const _e979d922 = () => interopDefault(import('..\\pages\\register.vue' /* webpackChunkName: "pages/register" */))
const _244597e8 = () => interopDefault(import('..\\pages\\olimpiada\\test\\index.vue' /* webpackChunkName: "pages/olimpiada/test/index" */))
const _a5fecac8 = () => interopDefault(import('..\\pages\\olimpiada\\test\\enter-code.vue' /* webpackChunkName: "pages/olimpiada/test/enter-code" */))
const _ea93980e = () => interopDefault(import('..\\pages\\olimpiada\\test\\erezhe.vue' /* webpackChunkName: "pages/olimpiada/test/erezhe" */))
const _5b4db114 = () => interopDefault(import('..\\pages\\olimpiada\\test\\katemen-jumys.vue' /* webpackChunkName: "pages/olimpiada/test/katemen-jumys" */))
const _1b08b994 = () => interopDefault(import('..\\pages\\index.vue' /* webpackChunkName: "pages/index" */))
const _af5d4d26 = () => interopDefault(import('..\\pages\\olimpiada\\test\\_id\\result.vue' /* webpackChunkName: "pages/olimpiada/test/_id/result" */))
const _740a61f2 = () => interopDefault(import('..\\pages\\olimpiada\\_slug.vue' /* webpackChunkName: "pages/olimpiada/_slug" */))

const emptyFn = () => {}

Vue.use(Router)

export const routerOptions = {
  mode: 'history',
  base: '/',
  linkActiveClass: 'nuxt-link-active',
  linkExactActiveClass: 'nuxt-link-exact-active',
  scrollBehavior,

  routes: [{
    path: "/about",
    component: _5a786f1e,
    name: "about"
  }, {
    path: "/login",
    component: _87b97366,
    name: "login"
  }, {
    path: "/olimpiada",
    component: _75c1033a,
    name: "olimpiada"
  }, {
    path: "/register",
    component: _e979d922,
    name: "register"
  }, {
    path: "/olimpiada/test",
    component: _244597e8,
    name: "olimpiada-test"
  }, {
    path: "/olimpiada/test/enter-code",
    component: _a5fecac8,
    name: "olimpiada-test-enter-code"
  }, {
    path: "/olimpiada/test/erezhe",
    component: _ea93980e,
    name: "olimpiada-test-erezhe"
  }, {
    path: "/olimpiada/test/katemen-jumys",
    component: _5b4db114,
    name: "olimpiada-test-katemen-jumys"
  }, {
    path: "/",
    component: _1b08b994,
    name: "index"
  }, {
    path: "/olimpiada/test/:id/result",
    component: _af5d4d26,
    name: "olimpiada-test-id-result"
  }, {
    path: "/olimpiada/:slug",
    component: _740a61f2,
    name: "olimpiada-slug"
  }],

  fallback: false
}

export function createRouter (ssrContext, config) {
  const base = (config._app && config._app.basePath) || routerOptions.base
  const router = new Router({ ...routerOptions, base  })

  // TODO: remove in Nuxt 3
  const originalPush = router.push
  router.push = function push (location, onComplete = emptyFn, onAbort) {
    return originalPush.call(this, location, onComplete, onAbort)
  }

  const resolve = router.resolve.bind(router)
  router.resolve = (to, current, append) => {
    if (typeof to === 'string') {
      to = normalizeURL(to)
    }
    return resolve(to, current, append)
  }

  return router
}
