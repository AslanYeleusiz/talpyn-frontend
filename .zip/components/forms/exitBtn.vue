<template>
    <button class="btn my_btn d-flex aj-c">
        <img src="~assets/images/ex.svg" alt="">
    </button>
</template>

<style scoped lang="scss">
    .my_btn{
        padding: 5px;
        width: 20px;
        height: 20px;
        border-radius: 50%;
        background: #C4C4C4;
        &:hover{
            background: #0045CB;
        }
        &:active{
            background: #0037A1;
        }
    }
</style>
