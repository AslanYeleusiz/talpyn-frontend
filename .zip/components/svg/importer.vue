<template>
    <svg width="20" height="20" viewBox="0 0 20 20" fill="none" xmlns="http://www.w3.org/2000/svg">
        <path d="M7.7666 9.7334L9.89994 11.8667L12.0333 9.7334" stroke="" stroke-width="1.5" stroke-miterlimit="10" stroke-linecap="round" stroke-linejoin="round" />
        <path d="M9.90039 3.3335V11.8085" stroke="" stroke-width="1.5" stroke-miterlimit="10" stroke-linecap="round" stroke-linejoin="round" />
        <path d="M16.6663 10.1499C16.6663 13.8332 14.1663 16.8166 9.99967 16.8166C5.83301 16.8166 3.33301 13.8332 3.33301 10.1499" stroke="" stroke-width="1.5" stroke-miterlimit="10" stroke-linecap="round" stroke-linejoin="round" />
    </svg>
</template>
