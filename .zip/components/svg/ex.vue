<template>
    <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
        <rect x="21.8186" width="3.08556" height="30.8556" rx="1.54278" transform="rotate(45 21.8186 0)" fill="" />
        <rect x="24" y="21.8182" width="3.08556" height="30.8556" rx="1.54278" transform="rotate(135 24 21.8182)" fill="" />
    </svg>
</template>
