<template>
    <svg width="21" height="20" viewBox="0 0 21 20" fill="none" xmlns="http://www.w3.org/2000/svg">
        <path d="M10.5003 18.3332C15.0837 18.3332 18.8337 14.5832 18.8337 9.99984C18.8337 5.4165 15.0837 1.6665 10.5003 1.6665C5.91699 1.6665 2.16699 5.4165 2.16699 9.99984C2.16699 14.5832 5.91699 18.3332 10.5003 18.3332Z" stroke="" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round" />
        <path d="M10.5 6.6665V10.8332" stroke="" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round" />
        <path d="M10.4951 13.3335H10.5026" stroke="" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" />
    </svg>
</template>
