<template>
    <svg width="21" height="20" viewBox="0 0 21 20" fill="none" xmlns="http://www.w3.org/2000/svg">
        <path d="M11.918 16.5817H17.2321" :stroke="color" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round" />
        <path fill-rule="evenodd" clip-rule="evenodd" d="M11.2136 4.12975C11.8277 3.34725 12.8202 3.38809 13.6036 4.00225L14.7619 4.91059C15.5452 5.52475 15.8227 6.47725 15.2086 7.26142L8.30106 16.0739C8.07023 16.3689 7.71773 16.5431 7.34273 16.5473L4.67857 16.5814L4.07523 13.9856C3.99023 13.6214 4.07523 13.2381 4.30607 12.9423L11.2136 4.12975Z" :stroke="color" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round" />
        <path d="M9.92188 5.78003L13.9169 8.9117" :stroke="color" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round" />
    </svg>
</template>


<script>
    export default {
        props: ['color'],
    }

</script>
