<template>
    <svg width="20" height="20" viewBox="0 0 20 20" fill="none" xmlns="http://www.w3.org/2000/svg">
        <path d="M16.1042 7.89062C16.1042 7.89062 15.6517 13.5031 15.3892 15.8673C15.2642 16.9965 14.5667 17.6581 13.4242 17.679C11.25 17.7181 9.07332 17.7206 6.89999 17.6748C5.80082 17.6523 5.11499 16.9823 4.99249 15.8731C4.72832 13.4881 4.27832 7.89062 4.27832 7.89062" stroke="" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round" />
        <path d="M17.2567 5.19987H3.125" stroke="" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round" />
        <path d="M14.5335 5.19998C13.8793 5.19998 13.316 4.73748 13.1877 4.09665L12.9852 3.08331C12.8602 2.61581 12.4368 2.29248 11.9543 2.29248H8.42682C7.94432 2.29248 7.52099 2.61581 7.39599 3.08331L7.19349 4.09665C7.06516 4.73748 6.50182 5.19998 5.84766 5.19998" stroke="" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round" />
    </svg>
</template>

<script>
export default {

}
</script>


<style scoped>

</style>
