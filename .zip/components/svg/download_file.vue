<template>
    <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none">
        <path fill-rule="evenodd" clip-rule="evenodd" d="M14.736 2.76172H8.084C6.025 2.76172 4.25 4.43072 4.25 6.49072V17.2277C4.25 19.4037 5.908 21.1147 8.084 21.1147H16.072C18.132 21.1147 19.802 19.2877 19.802 17.2277V8.03772L14.736 2.76172Z" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round" />
        <path d="M14.4727 2.75V5.659C14.4727 7.079 15.6217 8.231 17.0417 8.234C18.3577 8.237 19.7047 8.238 19.7957 8.232" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round" />
        <path d="M11.6406 16.0144V9.44141" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round" />
        <path d="M8.80273 13.1621L11.6407 16.0131L14.4797 13.1621" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round" />
    </svg>
</template>
