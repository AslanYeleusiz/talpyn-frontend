<template>
    <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 20 21" width="20" height="21">
        <path stroke-linecap="round" stroke-linejoin="round" stroke-miterlimit="10" stroke-width="1.5" d="M 9.99935 2.16675 C 5.39935 2.16675 1.66602 5.90008 1.66602 10.5001 C 1.66602 15.1001 5.39935 18.8334 9.99935 18.8334 C 14.5993 18.8334 18.3327 15.1001 18.3327 10.5001" />
        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="1.5" d="M 10.834 9.66658 L 17.6673 2.83325" />
        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="1.5" d="M 18.3336 6.19175 V 2.16675 H 14.3086" />
    </svg>
</template>
