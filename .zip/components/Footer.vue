<template>
    <div>
        <div class="home-elem-31">
            <div class="home-elem-29">
                <div class="home-elem-28"> <span class="home-elem-30 avatar">
                        <img src="~/assets/images/logo2.svg" alt="">
                    </span>
                    <div class="home-elem-32"> <span class="home-elem-33">
                            <p>Кодтау дағдыларын тексеру, әлемнің түкпір-түкпірінен келген үздік студенттермен жарысу, қызықты жүлделерді жеңіп алу мүмкіндігін жіберіп алмаңыз. Қазір тіркеліп, кодтау саяхатын Тест олимпиадасымен бастаңыз. </p>
                        </span><button class="home-elem-34">
                            <p>Қазір тіркелу </p>
                        </button></div>
                </div>
            </div>
            <div class="home-elem-35">
                <div class="home-elem-36"> <span class="home-elem-37">
                        <p>Тест олимпиадасы </p>
                    </span><span class="home-elem-38">
                        <p>Тест олимпиадасы - оқушыларды кодтау дағдыларын келесі деңгейге көтеруге сын айтуға және шабыттандыруға арналған алаң. Олимпиадаға қосылып, әлемнің түкпір-түкпірінен келген студенттермен кодтау жарыстарына қатысу. </p>
                    </span></div>
                <div class="home-elem-58">
                    <div class="home-elem-42"> <span class="home-elem-39"><a href="#home-elem-2" class="link" target="_self">
                                <p>Авторизациялау </p>
                            </a> </span><span class="home-elem-40">
                            <p>Олимпиадалық тест </p>
                        </span><span class="home-elem-41"><a href="#home-elem-9" class="link" target="_self">
                                <p>Контакт </p>
                            </a> </span></div>
                    <div class="home-elem-46"> <span class="home-elem-43">
                            <p>Twitter</p>
                        </span><span class="home-elem-44">
                            <p>Facebook</p>
                        </span><span class="home-elem-45">
                            <p>Instagram</p>
                        </span></div>
                </div>
            </div>
            <div class="home-elem-47"> <span class="home-elem-48">
                    <p>©2023 жылғы Тест олимпиадасы. Барлық құқықтар сақталған. </p>
                </span></div>
        </div>
    </div>
</template>


<script>
    //import Header from '@/components/Header.vue'
    export default {
        components: {
            //Header,
        },

    }

</script>

<style lang="scss" scoped>

</style>
